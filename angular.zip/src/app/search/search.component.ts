import { Movie } from './../Movie';
import { MovieService } from './../movie.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  genres: string[] = ['Crime', 'Drama', 'Action', 'Biography', 'Thriller'];
  searchFilter = new FormControl('', Validators.required);
  movies: Movie[];
  constructor(private _movieService: MovieService) { }

  ngOnInit(): void {
    this._movieService.getAllMovies().pipe(retry(1), catchError((error: HttpErrorResponse) => {
      console.log(error.status);
      window.alert(error.error.message);
      return throwError('Error fetching data from serve');
    })).subscribe((data: any) => {
      this.movies = data;
    });
  }

  applySearchFilter() {
    if (this.searchFilter.valid) {
      this._movieService.getMoviesByGenre(this.searchFilter.value).pipe(retry(1), catchError((error: HttpErrorResponse) => {
        console.log(error.status);
        window.alert(error.error.message);
        return throwError('Error fetching data from serve');
      })).subscribe((data: any) => {
        this.movies = data;
      });
    }
  }
}
