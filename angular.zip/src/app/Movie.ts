export interface Movie {
  movieName: string;
  rating: number;
  genre: string;
}
